To Change DRAM setting

1. Create and Fill content like EM6A6165TS_7G.mac
2. Change load file in common.mac 